pacman -S python3 python-pyqt4 python-pip
pip3 install selenium
sudo mkdir -p /usr/lib/sonot
cp sonot.zip /usr/lib/sonot/sonot.zip
sudo cp sonot /usr/bin/sonot