apt-get install python3 python3-pyqt4 python3-pip
pip3 install selenium
sudo mkdir -p /usr/lib/sonot
cp sonot.zip /usr/lib/sonot/sonot.zip
sudo cp sonot /usr/bin/sonot