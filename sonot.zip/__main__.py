import sonot
sonot.run()