from setuptools import setup

setup(
    name='sonot',
    version='0.0.1a',
    author='charalampos papaloizou',
    author_email='papaloizouc@gmail.com',
    install_requires=['selenium']
)